//package org.example;
//
//import static org.junit.jupiter.api.Assertions.assertTrue;
//
//import org.junit.jupiter.api.AfterEach;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//
//public class ThemeSwitcherTest {
//    private WebDriver driver;
//    private ThemeSwitcherPage themeSwitcherPage;
//
//    @BeforeEach
//    public void setUp() {
//        System.setProperty("webdriver.chrome.driver", "/Users/ummekulsumtumpa/Downloads/program_files/chromedriver-mac-arm64/chromedriver"); // Set the correct path
//        driver = new ChromeDriver();
//        themeSwitcherPage = new ThemeSwitcherPage(driver);
//        themeSwitcherPage.openURL("https://developer.mozilla.org/en-US/");
//    }
//
//    @Test
//    public void testThemeChangeFromOSDefaultToLightAndDark() throws InterruptedException {
//        // Change to OS Default theme
//        themeSwitcherPage.changeToOSDefaultTheme();
//        assertTrue(themeSwitcherPage.isThemeApplied("os-default"), "Failed to apply OS Default theme.");
//
//        // Change to Light theme
//        themeSwitcherPage.changeToLightTheme();
//        assertTrue(themeSwitcherPage.isThemeApplied("light"), "Failed to apply Light theme.");
//
//        // Change to Dark theme
//        themeSwitcherPage.changeToDarkTheme();
//        assertTrue(themeSwitcherPage.isThemeApplied("dark"), "Failed to apply Dark theme.");
//    }
//
//    @Test
//    public void testThemeChangeFromLightToDarkAndOSDefault() throws InterruptedException {
//        // Change to Light theme
//        themeSwitcherPage.changeToLightTheme();
//        assertTrue(themeSwitcherPage.isThemeApplied("light"), "Failed to apply Light theme.");
//
//        // Change to Dark theme
//        themeSwitcherPage.changeToDarkTheme();
//        assertTrue(themeSwitcherPage.isThemeApplied("dark"), "Failed to apply Dark theme.");
//
//        // Change to OS Default theme
//        themeSwitcherPage.changeToOSDefaultTheme();
//        assertTrue(themeSwitcherPage.isThemeApplied("os-default"), "Failed to apply OS Default theme.");
//    }
//
//    @Test
//    public void testThemeChangeFromDarkToLightAndOSDefault() throws InterruptedException {
//        // Change to Dark theme
//        themeSwitcherPage.changeToDarkTheme();
//        assertTrue(themeSwitcherPage.isThemeApplied("dark"), "Failed to apply Dark theme.");
//
//        // Change to Light theme
//        themeSwitcherPage.changeToLightTheme();
//        assertTrue(themeSwitcherPage.isThemeApplied("light"), "Failed to apply Light theme.");
//
//        // Change to OS Default theme
//        themeSwitcherPage.changeToOSDefaultTheme();
//        assertTrue(themeSwitcherPage.isThemeApplied("os-default"), "Failed to apply OS Default theme.");
//    }
//
//    @AfterEach
//    public void tearDown() {
//        driver.quit();
//    }
//}


package org.example;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ThemeSwitcherTest extends BaseTest {
    private ThemeSwitcherPage themeSwitcherPage;

    @BeforeEach
    public void initializePage() {
        themeSwitcherPage = new ThemeSwitcherPage(driver);
        themeSwitcherPage.openURL("https://developer.mozilla.org/en-US/");
    }

    @Test
    public void testChangeToOSDefaultTheme() throws InterruptedException {
        themeSwitcherPage.changeToOSDefaultTheme();
        assertTrue(themeSwitcherPage.isThemeApplied("os-default"), "Failed to apply OS Default theme.");
    }

    @Test
    public void testChangeToLightTheme() throws InterruptedException {
        themeSwitcherPage.changeToLightTheme();
        assertTrue(themeSwitcherPage.isThemeApplied("light"), "Failed to apply Light theme.");
    }

    @Test
    public void testChangeToDarkTheme() throws InterruptedException {
        themeSwitcherPage.changeToDarkTheme();
        assertTrue(themeSwitcherPage.isThemeApplied("dark"), "Failed to apply Dark theme.");
    }

    @Test
    public void testSwitchFromOSDefaultToLightTheme() throws InterruptedException {
        themeSwitcherPage.changeToOSDefaultTheme();
        themeSwitcherPage.changeToLightTheme();
        assertTrue(themeSwitcherPage.isThemeApplied("light"), "Failed to switch from OS Default to Light theme.");
    }

    @Test
    public void testSwitchFromOSDefaultToDarkTheme() throws InterruptedException {
        themeSwitcherPage.changeToOSDefaultTheme();
        themeSwitcherPage.changeToDarkTheme();
        assertTrue(themeSwitcherPage.isThemeApplied("dark"), "Failed to switch from OS Default to Dark theme.");
    }

    @Test
    public void testSwitchFromLightToDarkTheme() throws InterruptedException {
        themeSwitcherPage.changeToLightTheme();
        themeSwitcherPage.changeToDarkTheme();
        assertTrue(themeSwitcherPage.isThemeApplied("dark"), "Failed to switch from Light to Dark theme.");
    }

    @Test
    public void testSwitchFromLightToOSDefaultTheme() throws InterruptedException {
        themeSwitcherPage.changeToLightTheme();
        themeSwitcherPage.changeToOSDefaultTheme();
        assertTrue(themeSwitcherPage.isThemeApplied("os-default"), "Failed to switch from Light to os-default theme.");
    }

    @Test
    public void testSwitchFromDarkToOSDefaultTheme() throws InterruptedException {
        themeSwitcherPage.changeToDarkTheme();
        themeSwitcherPage.changeToOSDefaultTheme();
        assertTrue(themeSwitcherPage.isThemeApplied("os-default"), "Failed to switch from Dark to OS Default theme.");
    }

    @Test
    public void testSwitchFromDarkToLightTheme() throws InterruptedException {
        themeSwitcherPage.changeToDarkTheme();
        themeSwitcherPage.changeToLightTheme();
        assertTrue(themeSwitcherPage.isThemeApplied("light"), "Failed to switch from Dark to Light theme.");
    }

    @AfterEach
    public void tearDown() {
        driver.quit();
    }
}

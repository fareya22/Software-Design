package org.example;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public abstract class BaseTest {
    protected WebDriver driver;

    @BeforeEach
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "/Users/ummekulsumtumpa/Downloads/program_files/chromedriver-mac-arm64/chromedriver"); // Update the path
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        // Optionally, set implicit waits
        // driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    }

    @AfterEach
    public void tearDown() {
        // Control browser closure as discussed earlier
        if (Boolean.getBoolean("close.browser")) {
            driver.quit();
        }
    }
}

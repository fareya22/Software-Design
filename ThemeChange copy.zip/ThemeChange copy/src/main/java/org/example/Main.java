package org.example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Main {
    public static void main(String[] args) {
        // Set up ChromeDriver
        System.setProperty("webdriver.chrome.driver", "/Users/ummekulsumtumpa/Downloads/program_files/chromedriver-mac-arm64/chromedriver");
        WebDriver driver = new ChromeDriver();

        try {
            // Create an instance of ThemeSwitcherPage
            ThemeSwitcherPage themeSwitcherPage = new ThemeSwitcherPage(driver);

            // Open the URL
            themeSwitcherPage.openURL("https://developer.mozilla.org/en-US/");

            // Check and print the initial theme
            String initialTheme = themeSwitcherPage.getCurrentTheme();
            System.out.println("Initial Theme: " + initialTheme);
            Thread.sleep(2000); // Pause for 2 seconds

            // Change theme to Light and verify
            themeSwitcherPage.changeToLightTheme();
            System.out.println("Theme after setting to Light: " + themeSwitcherPage.getCurrentTheme());
            Thread.sleep(2000); // Pause for 2 seconds

            // Change theme to Dark and verify
            themeSwitcherPage.changeToDarkTheme();
            System.out.println("Theme after setting to Dark: " + themeSwitcherPage.getCurrentTheme());
            Thread.sleep(2000); // Pause for 2 seconds

            // Change theme to OS Default and verify
            themeSwitcherPage.changeToOSDefaultTheme();
            System.out.println("Theme after setting to OS Default: " + themeSwitcherPage.getCurrentTheme());
            Thread.sleep(2000); // Pause for 2 seconds

        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}

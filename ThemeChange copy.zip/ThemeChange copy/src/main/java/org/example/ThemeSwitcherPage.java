package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ThemeSwitcherPage extends BasePage {

    // Locators
    private By themeSwitcherMenu = By.cssSelector(".theme-switcher-menu");
    private By lightThemeIcon = By.cssSelector(".icon-theme-light");
    private By darkThemeIcon = By.cssSelector(".icon-theme-dark");
    private By osDefaultThemeIcon = By.cssSelector(".icon-theme-os-default");

    // Constructor
    public ThemeSwitcherPage(WebDriver driver) {
        super(driver);
    }

    // Methods
    public void openURL(String url) {
        driver.get(url);
    }

    public String getCurrentTheme() {
        return driver.findElement(By.tagName("html")).getAttribute("class");
    }

    public void changeToLightTheme() {
        click(themeSwitcherMenu);
        click(lightThemeIcon);
        // Consider using explicit waits instead of Thread.sleep
        waitForPageToLoad();
    }

    public void changeToDarkTheme() {
        click(themeSwitcherMenu);
        click(darkThemeIcon);
        waitForPageToLoad();
    }

    public void changeToOSDefaultTheme() {
        click(themeSwitcherMenu);
        click(osDefaultThemeIcon);
        waitForPageToLoad();
    }

    public boolean isThemeApplied(String themeClass) {
        String currentClass = getCurrentTheme();
        return currentClass.contains(themeClass);
    }

    // Optional: Replace Thread.sleep with a proper wait
    private void waitForPageToLoad() {
        // Implement a wait strategy, e.g., wait for a specific element to be visible
        // For demonstration, we'll use a simple implicit wait (not recommended)
        try {
            Thread.sleep(2000); // Replace with a better wait strategy
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

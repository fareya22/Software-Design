package utilities;


import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utilities.WebDriverManager;

public class Test1 {
    public static void main(String[] args) {
        WebDriver driver = WebDriverManager.getDriver();
        driver.get("https://developer.mozilla.org/en-US/docs/Web/WebDriver");
        driver.manage().window().maximize();

        try {
            //  the theme switcher button clickable korar jnno
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement themeSwitcher = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".theme-switcher-menu")));
            themeSwitcher.click();//click korbe

            // Switch to Light Theme
            WebElement lightThemeButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".icon-theme-light")));
            lightThemeButton.click();
            Thread.sleep(3000); // Wait briefly to allow the theme to apply

            //  light theme is apply hoyche kina seta check korbe
            String currentClass = driver.findElement(By.tagName("html")).getAttribute("class");
            if (currentClass.contains("light")) {
                System.out.println("Light theme applied successfully.");
            } else {
                System.out.println("Failed to apply light theme. Current class: " + currentClass);
            }

            // Switch to Dark Theme
            themeSwitcher.click();
            WebElement darkThemeButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".icon-theme-dark")));
            darkThemeButton.click();
            Thread.sleep(3000); // Waiting time to allow the theme to apply

            // Dark theme is apply hoyche kina seta check korbe
            currentClass = driver.findElement(By.tagName("html")).getAttribute("class");
            if (currentClass.contains("dark")) {
                System.out.println("Dark theme applied successfully.");
            } else {
                System.out.println("Failed to apply dark theme.Current class: " + currentClass);
            }

            // Switch to OS Default Theme
            themeSwitcher.click(); // Click to open theme options again
            WebElement osDefaultButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".icon-theme-os-default")));
            osDefaultButton.click();
            Thread.sleep(3000); // Waiting time  to allow the theme to apply

            // Default theme is apply hoyche kina seta check korbe
            currentClass = driver.findElement(By.tagName("html")).getAttribute("class");
            if (currentClass.contains("os-default")) {
                System.out.println("OS default theme applied successfully.");
            } else {
                System.out.println("Failed to apply OS default theme.Current class: " + currentClass);
            }


        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
    }
}